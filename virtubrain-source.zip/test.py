import pathlib, threading, http.server, functools, json, sys
from playwright.sync_api import sync_playwright
SITE=pathlib.Path('site').resolve(); SH=pathlib.Path('shots'); SH.mkdir(exist_ok=True)
import shutil
SERVE=pathlib.Path('/tmp/vbserve'); shutil.rmtree(SERVE, ignore_errors=True); shutil.copytree(SITE, SERVE); shutil.copytree('tests/fixture/data', SERVE/'data')
AXE=open('/home/claude/site/tests/node_modules/axe-core/axe.min.js').read()
srv=http.server.ThreadingHTTPServer(("127.0.0.1",8790),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(SERVE)))
threading.Thread(target=srv.serve_forever,daemon=True).start()
B="http://127.0.0.1:8790/"; R=[]
import html.parser, glob
class _P(html.parser.HTMLParser):
  def __init__(s): super().__init__(); s.st=[]; s.err=[]
  def handle_starttag(s,t,a):
    if t not in ('meta','link','img','input','br','hr','source','circle','line','path'): s.st.append(t)
  def handle_endtag(s,t):
    if t in ('circle','line','path'): return
    if s.st and s.st[-1]==t: s.st.pop()
    else: s.err.append(t)
def rec(n,ok,ev=""): R.append((n,ok,ev)); print(("PASS " if ok else "FAIL ")+n+(": "+str(ev) if ev else ""))
_bad={}
for f in glob.glob(str(SITE/'*.html')):
  q=_P(); q.feed(open(f).read())
  if q.err or q.st: _bad[f]=(q.err[:3],q.st)
with sync_playwright() as p:
  b=p.chromium.launch()
  for vw,vh,tag in [(1440,900,"desk"),(390,844,"mob")]:
    ctx=b.new_context(viewport={"width":vw,"height":vh}); ctx.route("**/fonts.g*/**",lambda r:r.abort())
    pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e: errs.append(str(e))); pg.on("console",lambda m: m.type=="error" and "ERR_FAILED" not in m.text and "404" not in m.text and errs.append(m.text))
    for f in ["index.html","platform.html","explore.html","pain-points.html","approach.html","practice.html","contact.html","404.html"]:
      pg.goto(B+f); pg.wait_for_timeout(700)
      pg.add_script_tag(content=AXE)
      v=pg.evaluate("async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa']}});return r.violations.filter(v=>['serious','critical'].includes(v.impact)).map(v=>v.id+':'+v.nodes.length+':'+v.nodes[0].target.join(' '))}")
      ov=pg.evaluate("document.documentElement.scrollWidth-innerWidth")
      rec(f"{tag} {f} axe+overflow", not v and ov<=0, f"{v} overflow={ov}")
      pg.screenshot(path=str(SH/f"{tag}-{f[:-5]}-top.png"))
    pg.goto(B+"index.html"); pg.wait_for_timeout(600)
    for y in range(0, pg.evaluate("document.body.scrollHeight"), 500): pg.evaluate(f"scrollTo(0,{y})"); pg.wait_for_timeout(40)
    pg.wait_for_timeout(1500)
    pg.screenshot(path=str(SH/f"{tag}-home-full.png"), full_page=True)
    rec(f"{tag} no JS errors", not errs, errs[:3])
    ctx.close()
  # story scroll states
  ctx=b.new_context(viewport={"width":1440,"height":900}); pg=ctx.new_page(); pg.goto(B+"index.html"); pg.wait_for_timeout(800)
  top=pg.evaluate("document.getElementById('story').offsetTop"); H=pg.evaluate("document.getElementById('story').offsetHeight-innerHeight")
  seen=[]
  for i,fr in enumerate([0.05,0.3,0.55,0.85]):
    pg.evaluate(f"scrollTo(0,{top}+{H}*{fr})"); pg.wait_for_timeout(900)
    seen.append(pg.evaluate("[...document.querySelectorAll('#story .scene')].findIndex(s=>s.classList.contains('on'))"))
    pg.screenshot(path=str(SH/f"story-{i}.png"))
  rec("pinned story advances through 4 levels", seen==[0,1,2,3], seen)
  ctx.close()
  rec("HTML nesting valid on every page", not _bad, _bad)
  # every referenced asset exists on disk and carries a content hash (no stale-cache risk)
  import re as _re
  missing=[]; unhashed=[]
  for f in glob.glob(str(SITE/'*.html')):
    for u in set(_re.findall(r'(?:src|href|srcset)="([^"]+)"', open(f).read())):
      for part in u.split(","):
        a=part.strip().split(" ")[0]
        if a.startswith("assets/"):
          if not (SITE/a).exists(): missing.append(a)
          if not _re.search(r"\.[0-9a-f]{10}\.(css|js|webp)$", a): unhashed.append(a)
  rec("all asset URLs exist and are content-hashed", not missing and not unhashed, (missing[:3], unhashed[:3]))
  # every image on every page actually renders (after scrolling to trigger lazy loading), desktop and mobile
  for vw in (1440, 390):
    ctx=b.new_context(viewport={"width":vw,"height":900}); pg=ctx.new_page(); bad={}
    for f in ["index.html","platform.html","explore.html","pain-points.html","approach.html","practice.html","contact.html"]:
      pg.goto(B+f); pg.wait_for_timeout(300)
      for y in range(0, pg.evaluate("document.body.scrollHeight"), 400): pg.evaluate(f"scrollTo(0,{y})"); pg.wait_for_timeout(30)
      pg.wait_for_timeout(600)
      r=pg.evaluate("[...document.images].map(i=>[i.currentSrc.split('/').pop(), i.complete && i.naturalWidth>0])")
      if (not r and f in ("index.html","platform.html","approach.html","practice.html","contact.html")) or not all(ok for _,ok in r): bad[f]=r
    rec(f"every photo renders on every page ({vw}px)", not bad, bad); ctx.close()
  # failure drill: if an image 404s, no broken box shows and the heading stays visible
  ctx=b.new_context(viewport={"width":1440,"height":900}); ctx.route("**/gbs-floor*.webp", lambda r: r.fulfill(status=404, body="")); pg=ctx.new_page()
  pg.goto(B+"practice.html"); pg.wait_for_timeout(800)
  vis=pg.evaluate("[...document.images].filter(i=>getComputedStyle(i).display!=='none' && i.offsetParent!==null && !(i.naturalWidth>0)).length")
  h1=pg.locator("h1").is_visible()
  rec("failure drill: a missing photo is removed cleanly, heading still visible", vis==0 and h1, f"visible broken={vis}")
  ctx.close()
  # ---------- demos contained in the site ----------
  ext=[]; brand=[]
  for f in glob.glob(str(SITE/'*.html')):
    h=open(f).read()
    ext+= [ (pathlib.Path(f).name,u) for u in _re.findall(r'href="(https?://[^"]+)"', h) if "fonts.g" not in u]
    if "Process Reinvention Hub" in h: brand.append(pathlib.Path(f).name)
  rec("contained: no page links out of the site (demos are internal)", not ext, ext[:4])
  rec("brand: old practice name gone from every page", not brand, brand)
  ctx=b.new_context(viewport={"width":1440,"height":900}); pg=ctx.new_page(); errs=[]; pg.on("pageerror",lambda e: errs.append(str(e)))
  pg.goto(B+"explore.html"); pg.wait_for_selector("#xp-detail h2"); h=pg.locator("#xp-detail h2").inner_text()
  rec("explorer: opens on the flagship process by default", "Manage Warehouse Operations" in h, h)
  navok=pg.evaluate("[...document.querySelectorAll('#nav a')].map(a=>a.textContent.trim()+(a.getAttribute('aria-current')?'*':''))")
  rec("explorer: nav shows Explorer as the current page; site chrome present", "Explorer*" in navok and "Pain points" in navok and pg.locator("footer").count()==1, navok)
  pg.locator('.xp-fns [data-f="information-technology-management"]').click(); pg.wait_for_timeout(150)
  pg.locator('.proc-btn').nth(1).click(); pg.wait_for_timeout(150)
  h2=pg.locator("#xp-detail h2").inner_text(); hash1=pg.evaluate("location.hash")
  pg.go_back(); pg.wait_for_timeout(250); h3=pg.locator("#xp-detail h2").inner_text()
  rec("explorer: choosing a process updates the view and URL; Back returns", "Information Technology" in h2 and "p=11.1.2" in hash1 and h3!=h2, f"{h2} | {hash1} | back→{h3}")
  pg.locator('[data-i="banking"]').click(); pg.locator('[data-c="SG"]').click(); pg.wait_for_timeout(150)
  lens=pg.locator(".lens-cards").inner_text(); pg.reload(); pg.wait_for_selector("#xp-detail h2"); lens2=pg.locator(".lens-cards").inner_text()
  rec("explorer: industry and country lenses change the content and survive reload", "banking lens" in lens and "SG lens" in lens and lens==lens2, lens[:90])
  pg.fill("#xp-q","warehouse"); pg.wait_for_timeout(400); cnt=pg.locator("#xp-count").inner_text(); hit=pg.locator('.proc-btn[data-p="4.4.1"]').count()
  rec("explorer: search finds processes across all functions", hit==1, cnt)
  pg.locator('.proc-btn[data-p="4.4.1"]').click(); pg.wait_for_timeout(200)
  pg.locator("text=See all").click(); pg.wait_for_selector(".pp-card"); sc=pg.locator("#pp-scope").inner_text(); n=pg.locator(".pp-card").count()
  rec("explorer → pain points: scoped to the same process", "4.4.1" in sc and n==2, f"{sc} cards={n}")
  pg.locator(".pp-card .text-link").first.click(); pg.wait_for_selector("#xp-detail h2"); back=pg.locator("#xp-detail h2").inner_text()
  rec("pain point → explorer: opens the exact process", "Manage Warehouse Operations" in back, back)
  pg.goto(B+"pain-points.html"); pg.wait_for_selector(".pp-card")
  total=pg.locator("#pp-count").inner_text(); pg.locator('[data-sev="High"]').click(); pg.wait_for_timeout(150)
  sevs=set(pg.locator(".pp-card .psev").all_inner_texts()); pg.select_option("#pp-k","control-gap"); pg.wait_for_timeout(150)
  cats=set(pg.locator(".pp-card .cat").all_inner_texts()); c2=pg.locator("#pp-count").inner_text()
  pg.fill("#pp-q","zzzz-nothing"); pg.wait_for_timeout(400); empty=pg.locator(".pp-empty").count()
  pg.click("[data-reset]"); pg.wait_for_timeout(200); after=pg.locator(".pp-card").count(); more=pg.locator("#pp-more").is_visible()
  pg.click("#pp-more"); pg.wait_for_timeout(200); after2=pg.locator(".pp-card").count(); foc=pg.evaluate("document.activeElement.tagName")
  rec("pain library: severity, category, search, empty state, clear, show more", sevs=={"High"} and cats=={"Control / Compliance Gap"} and empty==1 and after==24 and more and after2==48 and foc=="H3", f"{total} → {c2}; {after}→{after2}")
  pg.goto(B+"explore.html#p=4.4.1"); pg.wait_for_selector("#xp-detail h2"); pg.locator("text=Discuss this process").click(); pg.wait_for_timeout(300)
  msg=pg.input_value("#t-msg"); fnv=pg.evaluate("document.getElementById('t-fn').selectedOptions[0].text")
  rec("explorer → contact: message and function prefilled", "4.4.1" in msg and fnv.startswith("Supply Chain"), f"{msg} | {fnv}")
  rec("demos: no JS errors", not errs, errs[:2]); ctx.close()
  # data outage drill
  ctx=b.new_context(viewport={"width":1440,"height":900}); pg=ctx.new_page(); down={"on":True}
  ctx.route("**/data/*.json", lambda r: r.fulfill(status=503, body="") if down["on"] else r.continue_())
  pg.goto(B+"explore.html"); pg.wait_for_timeout(600); err=pg.locator(".demo-error").is_visible(); chrome=pg.locator("#nav").count()==1
  down["on"]=False; pg.click(".demo-error button"); pg.wait_for_selector("#xp-detail h2", timeout=5000); ok=pg.locator("#xp-detail h2").is_visible()
  rec("outage drill: data failure shows a retry message inside the site, retry recovers", err and chrome and ok); ctx.close()
  # mobile explorer usable
  ctx=b.new_context(viewport={"width":390,"height":844}); pg=ctx.new_page(); pg.goto(B+"explore.html"); pg.wait_for_selector("#xp-detail h2")
  pg.select_option("#xp-fn-select","finance-accounting"); pg.wait_for_timeout(150); pg.locator(".proc-btn").first.click(); pg.wait_for_timeout(600)
  top=pg.evaluate("document.getElementById('xp-detail').getBoundingClientRect().top"); ov=pg.evaluate("document.documentElement.scrollWidth-innerWidth")
  pg.screenshot(path=str(SH/"mob-explorer.png"))
  rec("mobile explorer: function picker works, detail scrolls into view, no overflow", top<200 and ov<=0, f"top={top:.0f} overflow={ov}"); ctx.close()
  # interactions
  ctx=b.new_context(viewport={"width":1440,"height":900}); pg=ctx.new_page(); pg.goto(B+"index.html"); pg.wait_for_timeout(500)
  pg.locator("#explorer button.fn").nth(5).focus(); pg.keyboard.press("ArrowDown"); pg.wait_for_timeout(100)
  t=pg.locator("#explorer .pane h3").inner_text(); sel=pg.evaluate("document.activeElement.getAttribute('aria-selected')")
  rec("explorer: arrow keys move selection and update panel", t.startswith("Retail") and sel=="true", t)
  pg.click("#talk button[type=submit]"); pg.wait_for_timeout(200)
  e1=pg.locator("#e-name").inner_text(); foc=pg.evaluate("document.activeElement.name")
  pg.route(B, lambda r: r.fulfill(status=200, body="ok") if r.request.method=="POST" else r.continue_())
  pg.fill("#t-name","Ana Cruz"); pg.fill("#t-email","ana@example.com"); pg.fill("#t-msg","Close takes too long."); pg.click("#talk button[type=submit]"); pg.wait_for_timeout(500)
  ok=pg.locator("#talk-status").inner_text()
  rec("form: errors named and focused; success is explicit", "Enter your name" in e1 and foc=="name" and ok.startswith("Sent."), ok)
  ctx.close()
  ctx=b.new_context(viewport={"width":390,"height":844}); pg=ctx.new_page(); pg.goto(B+"platform.html"); pg.wait_for_timeout(300)
  pg.click(".menu-btn"); o=pg.evaluate("document.getElementById('nav').classList.contains('open')"); pg.keyboard.press("Escape"); c=pg.evaluate("!document.getElementById('nav').classList.contains('open') && document.activeElement.classList.contains('menu-btn')")
  rec("mobile menu opens and closes with Escape, focus returns", o and c); ctx.close()
  # lab performance, mobile, CPU x4, fonts blocked
  ctx=b.new_context(viewport={"width":390,"height":844}); ctx.route("**/fonts.g*/**",lambda r:r.abort()); pg=ctx.new_page()
  cdp=ctx.new_cdp_session(pg); cdp.send("Emulation.setCPUThrottlingRate",{"rate":4})
  pg.add_init_script("window.__l=0;window.__c=0;new PerformanceObserver(l=>{for(const e of l.getEntries())window.__l=e.startTime}).observe({type:'largest-contentful-paint',buffered:true});new PerformanceObserver(l=>{for(const e of l.getEntries())if(!e.hadRecentInput)window.__c+=e.value}).observe({type:'layout-shift',buffered:true})")
  pg.goto(B+"index.html"); pg.wait_for_timeout(2500); lcp,cls=pg.evaluate("[window.__l,window.__c]")
  broken=pg.evaluate("[...document.images].filter(i=>i.complete&&!i.naturalWidth).length")
  rec("perf (lab, 390px, CPU x4): LCP<=2500ms, CLS<=0.1, no broken images", lcp<=2500 and cls<=0.1 and broken==0, f"LCP={lcp:.0f}ms CLS={cls:.3f} broken={broken}")
  ctx.close()
  # no-JS: all content visible
  ctx=b.new_context(java_script_enabled=False); pg=ctx.new_page(); pg.goto(B+"index.html")
  hid=pg.evaluate("[...document.querySelectorAll('h2,p')].filter(e=>getComputedStyle(e.closest('.reveal')||e).opacity==='0').length")
  rec("no-JS: no content hidden", hid==0, hid); ctx.close()
  b.close()
srv.shutdown()
print(sum(1 for r in R if r[1]),"/",len(R))
