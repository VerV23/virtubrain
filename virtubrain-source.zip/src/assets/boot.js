document.documentElement.classList.add("js");
// If any photo fails to load, remove it instead of showing a broken-image box; backgrounds and text stay intact.
document.addEventListener("error", function (e) {
  var t = e.target;
  if (!t || t.tagName !== "IMG") return;
  var fig = t.closest && t.closest("figure");
  if (fig) fig.hidden = true; else t.style.display = "none";
}, true);
