/* VirtuBrain site behaviour. No dependencies. Everything degrades to readable static content. */
(() => {
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const DATA = JSON.parse($("#vb-data")?.textContent || "{}");

  /* Header: transparent over dark heroes, solid after scrolling */
  const head = $(".site-head");
  const onScroll = () => head && head.classList.toggle("solid", scrollY > 24);
  addEventListener("scroll", onScroll, { passive: true }); onScroll();

  /* Mobile menu */
  const mb = $(".menu-btn"), nav = $("#nav");
  if (mb && nav) {
    const set = (o) => { nav.classList.toggle("open", o); mb.setAttribute("aria-expanded", o); mb.textContent = o ? "Close" : "Menu"; };
    mb.addEventListener("click", () => set(!nav.classList.contains("open")));
    addEventListener("keydown", (e) => { if (e.key === "Escape" && nav.classList.contains("open")) { set(false); mb.focus(); } });
    $$("a", nav).forEach((a) => a.addEventListener("click", () => set(false)));
  }

  /* Optional photography: hide any figure whose image is not present yet */
  $$("img[data-optional]").forEach((img) => {
    const fail = () => { const f = img.closest("figure[data-photo]"); if (f) f.setAttribute("data-missing", ""); img.remove(); };
    if (img.complete && !img.naturalWidth) fail(); else img.addEventListener("error", fail);
  });

  /* Signature: the calibration dial. 13 functions around a 240° arc, sized by process count. */
  const dial = $("#dial");
  if (dial && DATA.functions) {
    const fns = DATA.functions, cx = 260, cy = 260, R = 210, start = -210, sweep = 240;
    const ns = "http://www.w3.org/2000/svg", g = $("#dial-ticks", dial);
    for (let i = 0; i <= 120; i++) {
      const a = (start + (sweep * i) / 120) * Math.PI / 180, major = i % 10 === 0, r1 = R + 14, r2 = R + (major ? 30 : 22);
      const l = document.createElementNS(ns, "line");
      l.setAttribute("x1", cx + r1 * Math.cos(a)); l.setAttribute("y1", cy + r1 * Math.sin(a));
      l.setAttribute("x2", cx + r2 * Math.cos(a)); l.setAttribute("y2", cy + r2 * Math.sin(a));
      l.setAttribute("class", "tick" + (major ? " major" : "")); g.appendChild(l);
    }
    const dots = fns.map((f, i) => {
      const deg = start + (sweep * (i + 0.5)) / fns.length, a = deg * Math.PI / 180;
      const c = document.createElementNS(ns, "circle");
      c.setAttribute("cx", cx + (R - 8) * Math.cos(a)); c.setAttribute("cy", cy + (R - 8) * Math.sin(a));
      c.setAttribute("r", 4 + f[2] / 4); c.setAttribute("class", "fn-dot"); g.appendChild(c);
      return { deg: deg + 90, c, f };
    });
    const read = $("#dial-read b"), sub = $("#dial-read span");
    let k = 5; // start on Supply Chain: the flagship process lives there
    let settle;
    const show = (i, now) => {
      dial.style.setProperty("--needle", dots[i].deg + "deg");
      clearTimeout(settle); // light the mark only when the needle arrives, so reading and pointer always agree
      settle = setTimeout(() => {
        dots.forEach((d, j) => d.c.classList.toggle("on", j === i));
        read.textContent = dots[i].f[0]; sub.textContent = `${dots[i].f[1]} process groups, ${dots[i].f[2]} Level 3 processes`;
      }, now || reduce ? 0 : 1150);
    };
    show(k, true);
    requestAnimationFrame(() => setTimeout(() => dial.classList.add("go"), 250));
    if (!reduce) {
      let timer = setInterval(() => { k = (k + 1) % dots.length; show(k); }, 3200);
      const stop = () => { clearInterval(timer); timer = null; };
      $("#dial-pause")?.addEventListener("click", (e) => {
        if (timer) { stop(); e.currentTarget.textContent = "Resume the dial"; e.currentTarget.setAttribute("aria-pressed", "true"); }
        else { timer = setInterval(() => { k = (k + 1) % dots.length; show(k); }, 3200); e.currentTarget.textContent = "Pause the dial"; e.currentTarget.setAttribute("aria-pressed", "false"); }
      });
    } else $("#dial-pause")?.remove();
  }

  /* Pinned story: scroll progress through four levels of the taxonomy */
  const story = $("#story");
  if (story) {
    const steps = $$(".story-step", story), scenes = $$(".scene", story), pips = $$(".story-progress i", story);
    const desktop = () => innerWidth > 860 && !reduce;
    let cur = -1;
    const set = (i, p) => {
      if (i !== cur) {
        steps.forEach((s, j) => s.classList.toggle("on", j === i));
        scenes.forEach((s, j) => { s.classList.toggle("on", j === i); s.classList.toggle("past", j < i); s.setAttribute("aria-hidden", j !== i); });
        pips.forEach((s, j) => s.classList.toggle("on", j <= i)); cur = i;
      }
      steps[i]?.style.setProperty("--p", Math.round(p * 100) + "%");
    };
    const stage = $(".story-stage", story);
    const tick = () => {
      stage.classList.toggle("linear", !desktop());
      if (!desktop()) { scenes.forEach((s) => s.removeAttribute("aria-hidden")); return; }
      const r = story.getBoundingClientRect(), total = story.offsetHeight - innerHeight;
      const prog = Math.min(1, Math.max(0, -r.top / total)), n = scenes.length;
      const i = Math.min(n - 1, Math.floor(prog * n)); set(i, prog * n - i);
    };
    addEventListener("scroll", () => requestAnimationFrame(tick), { passive: true }); addEventListener("resize", tick); tick();
  }

  /* Reveals + bars + counters, once, when seen */
  const io = new IntersectionObserver((es) => es.forEach((e) => {
    if (!e.isIntersecting) return; const el = e.target; io.unobserve(el);
    el.classList.add("in");
    $$(".fill", el).forEach((f) => (f.style.width = f.dataset.w));
    $$("[data-count]", el).forEach((n) => {
      const to = +n.dataset.count; if (reduce) { n.textContent = to; return; }
      const t0 = performance.now(), d = 1400;
      const step = (t) => { const p = Math.min(1, (t - t0) / d); n.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }), { threshold: 0.18 });
  $$(".reveal, [data-observe]").forEach((el) => io.observe(el));

  /* Explorer teaser: real function coverage from the published taxonomy */
  const ex = $("#explorer");
  if (ex && DATA.functions) {
    const nav = $("nav", ex), pane = $(".pane", ex), maxP = Math.max(...DATA.functions.map((f) => f[2]));
    nav.innerHTML = DATA.functions.map((f, i) => `<button class="fn" role="tab" id="fn-${i}" aria-controls="fn-pane" aria-selected="${i === 5}" tabindex="${i === 5 ? 0 : -1}">${f[0]}<em>${f[2]}</em></button>`).join("");
    const btns = $$("button", nav);
    const pick = (i, focus) => {
      btns.forEach((b, j) => { b.setAttribute("aria-selected", j === i); b.tabIndex = j === i ? 0 : -1; });
      if (focus) btns[i].focus();
      const f = DATA.functions[i];
      $("h3", pane).textContent = f[0];
      $("#ex-groups").textContent = f[1]; $("#ex-procs").textContent = f[2];
      const open = $("#ex-open"); if (open && DATA.functionIds) open.href = "explore.html#f=" + DATA.functionIds[i];
      $$(".meter i", pane).forEach((m, j) => m.classList.toggle("on", j < f[2]));
      pane.setAttribute("aria-labelledby", "fn-" + i);
    };
    btns.forEach((b, i) => b.addEventListener("click", () => pick(i)));
    nav.addEventListener("keydown", (e) => {
      const i = btns.indexOf(document.activeElement); if (i < 0) return;
      const n = { ArrowDown: i + 1, ArrowRight: i + 1, ArrowUp: i - 1, ArrowLeft: i - 1, Home: 0, End: btns.length - 1 }[e.key];
      if (n === undefined) return; e.preventDefault(); pick((n + btns.length) % btns.length, true);
    });
    $(".meter", pane).innerHTML = "<i></i>".repeat(maxP);
    pick(5);
  }

  /* Contact prefill from explorer / pain-point links: contact.html?process=4.4.1&name=...&fn=... */
  const qp = new URLSearchParams(location.search);
  if ($("#talk") && (qp.get("process") || qp.get("fn"))) {
    const fnName = qp.get("fn"), sel = $("#t-fn"), msg = $("#t-msg");
    if (fnName && sel) [...sel.options].forEach((o) => { if (o.text === fnName) sel.value = o.value || o.text; });
    if (qp.get("process") && msg && !msg.value) msg.value = `I'd like to discuss process ${qp.get("process")}${qp.get("name") ? " (" + qp.get("name") + ")" : ""}. `;
  }

  /* Contact form: Netlify Forms on the live site; honest outcome either way */
  const form = $("#talk");
  if (form) form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const st = $("#talk-status"), fd = new FormData(form), errs = [];
    $$(".err", form).forEach((x) => (x.textContent = ""));
    const need = (k, msg) => { if (!String(fd.get(k) || "").trim()) { errs.push(k); $(`#e-${k}`).textContent = msg; } };
    need("name", "Enter your name."); need("email", "Enter your work email.");
    if (fd.get("email") && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fd.get("email"))) { errs.push("email"); $("#e-email").textContent = "Check the email address; it should look like name@company.com."; }
    need("message", "Tell us briefly what you want to calibrate.");
    if (errs.length) { $(`[name=${errs[0]}]`, form).focus(); st.className = "status bad"; st.textContent = `Fix ${errs.length} field${errs.length > 1 ? "s" : ""} to send.`; return; }
    if (fd.get("company-website")) return; // honeypot
    const btn = $("button[type=submit]", form); btn.disabled = true; btn.textContent = "Sending…";
    try {
      const r = await fetch("/", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(fd).toString() });
      if (!r.ok) throw new Error(r.status);
      form.reset(); st.className = "status ok"; st.textContent = `Sent. Replies come to ${fd.get("email")}.`;
    } catch {
      const body = encodeURIComponent(`${fd.get("message")}\n\n${fd.get("name")}${fd.get("company") ? ", " + fd.get("company") : ""}`);
      st.className = "status bad";
      st.innerHTML = `Not sent: the form service didn't respond. <a href="mailto:vervillarico23@gmail.com?subject=VirtuBrain%20inquiry&body=${body}">Send it by email instead</a>; your message is already filled in.`;
    } finally { btn.disabled = false; btn.textContent = "Send"; st.focus(); }
  });
})();
