/* VirtuBrain demos, hosted inside the site: framework explorer and pain-point library.
   Data is served same-origin at /data/*.json (Netlify proxies it from the VirtuBrain data store).
   State lives in the URL hash, so every view is linkable and Back/Forward work. */
(() => {
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const IND = { retail: "Retail", tech: "Technology", insurance: "Insurance", banking: "Banking", hotel: "Hospitality", manufacturing: "Manufacturing" };
  const CTY = { PH: "Philippines", US: "United States", SG: "Singapore" };
  const SEV = ["High", "Medium", "Low"];
  const ARROW = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const cache = {};
  const load = (name) => (cache[name] ||= fetch(`/data/${name}.json`, { headers: { Accept: "application/json" } }).then((r) => { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); }));
  const readHash = () => Object.fromEntries(new URLSearchParams(location.hash.slice(1)));
  const writeHash = (st, push) => {
    const h = "#" + new URLSearchParams(Object.entries(st).filter(([, v]) => v !== "" && v != null)).toString();
    if (h !== location.hash) history[push ? "pushState" : "replaceState"](null, "", h === "#" ? location.pathname : h);
  };
  const failed = (host, retry) => {
    host.removeAttribute("aria-busy");
    host.innerHTML = `<div class="demo-error" role="alert"><h2>The platform data didn't load.</h2><p>This is usually a brief connection problem. Your place on the page is kept.</p><button class="btn btn-amber" type="button">Try again</button></div>`;
    $("button", host).addEventListener("click", () => { Object.keys(cache).forEach((k) => delete cache[k]); retry(); });
  };

  /* ------------------------------------------------------------------ Explorer */
  const xp = $("#xp");
  if (xp) {
    const shell = xp.innerHTML;
    let T, P = null, index = [], byId = new Map(), painBy = new Map();
    const boot = async () => {
      xp.innerHTML = shell; xp.setAttribute("aria-busy", "true");
      try { T = await load("master-taxonomy"); } catch { return failed(xp, boot); }
      T.functions.forEach((f) => f.processGroups.forEach((g) => g.processes.forEach((p) => {
        const rec = { f, g, p, hay: [p.id, p.name, p.description, ...p.activities.flatMap((a) => [a.name, ...a.tasks.map((t) => t.name)])].join(" ").toLowerCase() };
        index.push(rec); byId.set(p.id, rec);
      })));
      xp.removeAttribute("aria-busy");
      render(false);
      load("pain-points").then((d) => { P = d; d.painPoints.forEach((x) => { if (!painBy.has(x.processId)) painBy.set(x.processId, []); painBy.get(x.processId).push(x); }); renderDetail(); }).catch(() => { P = false; renderDetail(); });
    };
    const flagship = (fid) => (T.meta.flagshipProcesses || []).find((x) => x.functionId === fid)?.processId;
    const resolve = () => {
      const st = readHash();
      let f = T.functions.find((x) => x.functionId === st.f);
      let rec = st.p && byId.get(st.p);
      if (rec && (!f || rec.f !== f)) f = rec.f;
      if (!f) f = T.functions.find((x) => x.functionId === "supply-chain-operations-logistics") || T.functions[0];
      if (!rec) rec = byId.get(flagship(f.functionId)) || byId.get(f.processGroups[0].processes[0].id);
      return { f, rec, i: IND[st.i] ? st.i : "retail", c: CTY[st.c] ? st.c : "PH", q: st.q || "" };
    };
    const set = (patch, push = true) => { const cur = resolve(); writeHash({ f: cur.f.functionId, p: cur.rec.p.id, i: cur.i, c: cur.c, q: cur.q, ...patch }, push); render(true); };

    const render = (fromUser) => {
      const s = resolve();
      // lenses
      $("#lens-i").innerHTML = Object.entries(IND).map(([k, v]) => `<button type="button" class="chip" data-i="${k}" aria-pressed="${k === s.i}">${v}</button>`).join("");
      $("#lens-c").innerHTML = Object.entries(CTY).map(([k, v]) => `<button type="button" class="chip" data-c="${k}" aria-pressed="${k === s.c}">${v}</button>`).join("");
      // functions
      const count = (f) => f.processGroups.reduce((n, g) => n + g.processes.length, 0);
      $("#xp-fns").innerHTML = T.functions.map((f) => `<button type="button" class="fn" data-f="${f.functionId}" ${f === s.f && !s.q ? 'aria-current="true"' : ""}><span>${esc(f.functionName)}</span><em>${count(f)}</em></button>`).join("");
      $("#xp-fn-select").innerHTML = T.functions.map((f) => `<option value="${f.functionId}" ${f === s.f ? "selected" : ""}>${esc(f.functionName)} (${count(f)})</option>`).join("");
      // list
      const q = $("#xp-q"); if (document.activeElement !== q) q.value = s.q;
      const list = $("#xp-procs");
      if (s.q.trim()) {
        const terms = s.q.toLowerCase().split(/\s+/).filter(Boolean);
        const hits = index.filter((r) => terms.every((t) => r.hay.includes(t)));
        list.innerHTML = `<p class="xp-count" id="xp-count">${hits.length} process${hits.length === 1 ? "" : "es"} match “${esc(s.q)}”</p>` +
          (hits.length ? `<ul>${hits.slice(0, 60).map((r) => procBtn(r, s)).join("")}</ul>` : `<p class="fine">Try a broader word, such as “invoice”, “payroll” or “close”. <button type="button" class="linkish" data-clear>Clear search</button></p>`);
      } else {
        list.innerHTML = `<p class="xp-count" id="xp-count">${esc(s.f.functionName)}: ${count(s.f)} processes</p>` + s.f.processGroups.map((g) => `<div class="grp-h">${esc(g.groupId)} ${esc(g.groupName)}</div><ul>${g.processes.map((p) => procBtn(byId.get(p.id), s)).join("")}</ul>`).join("");
      }
      renderDetail();
      if (fromUser === "proc") { const h = $("#xp-detail h2"); if (h) { h.focus({ preventScroll: true }); if (innerWidth <= 980) $("#xp-detail").scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" }); } }
    };
    const procBtn = (r, s) => `<li><button type="button" class="proc-btn" data-p="${r.p.id}" ${r.p.id === s.rec.p.id ? 'aria-current="true"' : ""}><span class="pid">${esc(r.p.id)}</span><span>${esc(r.p.name)}</span>${r.p.hasStepDetail ? '<i class="tag">Curated</i>' : ""}</button></li>`;

    const renderDetail = () => {
      if (!T) return;
      const s = resolve(), { f, g, p } = s.rec, cal = p.calibration || {};
      const pains = P ? painBy.get(p.id) || [] : null;
      const curated = p.hasStepDetail;
      $("#xp-detail").innerHTML = `
        <p class="crumb">${esc(f.functionName)} <span aria-hidden="true">›</span> ${esc(g.groupId)} ${esc(g.groupName)}</p>
        <h2 tabindex="-1"><span class="pid">${esc(p.id)}</span> ${esc(p.name)}</h2>
        <p class="desc">${esc(p.description)}</p>
        <dl class="io"><div><dt>Starts when</dt><dd>${esc(p.trigger)}</dd></div><div><dt>Produces</dt><dd>${esc(p.output)}</dd></div></dl>
        <div class="lens-cards">
          <section aria-label="Industry lens"><h3><span>Industry lens</span>${IND[s.i]}</h3><p>${esc(cal.industry?.[s.i] || "No industry note for this process.")}</p></section>
          <section aria-label="Country lens"><h3><span>Country lens</span>${CTY[s.c]}</h3><p>${esc(cal.country?.[s.c] || "No country note for this process.")}</p></section>
        </div>
        <div class="sk">
          <div><h3>Typical systems</h3><ul class="chips-ro">${(cal.systems || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>
          <div><h3>Representative KPIs</h3><ul class="kpis">${(cal.kpis || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>
        </div>
        <h3 class="sec">Breakdown to the step <span class="fine">${curated ? "Curated step detail" : "Steps modeled from the Level 3 to 5 structure"}</span></h3>
        <div class="tree">${p.activities.map((a, ai) => `
          <details ${ai === 0 ? "open" : ""}><summary><span class="pid">${esc(a.id)}</span> ${esc(a.name)} <em>${a.tasks.length} task${a.tasks.length === 1 ? "" : "s"}</em></summary>
            ${a.tasks.map((t) => `<div class="task"><p><span class="pid">${esc(t.id)}</span> ${esc(t.name)}</p>${(t.steps || []).length ? `<ol>${t.steps.map((st) => `<li>${esc(st)}</li>`).join("")}</ol>` : ""}</div>`).join("")}
          </details>`).join("")}</div>
        <h3 class="sec">Pain points on this process</h3>
        ${pains === null ? `<p class="fine">Loading pain points…</p>` : P === false ? `<p class="fine">Pain points couldn't load. <a href="pain-points.html#p=${encodeURIComponent(p.id)}">Open the pain-point library</a>.</p>` :
          pains.length ? `<ul class="pp-mini">${pains.slice(0, 3).map((x) => `<li><span class="psev psev-${x.severity.toLowerCase()}">${esc(x.severity)}</span><b>${esc(x.title)}</b><span class="fine">${esc(x.categoryLabel)}</span></li>`).join("")}</ul>
            <p><a class="text-link" href="pain-points.html#p=${encodeURIComponent(p.id)}">See all ${pains.length} for this process ${ARROW}</a></p>` : `<p class="fine">No pain points recorded for this process.</p>`}
        <div class="row actions">
          <a class="btn btn-amber" href="contact.html?process=${encodeURIComponent(p.id)}&name=${encodeURIComponent(p.name)}&fn=${encodeURIComponent(f.functionName)}#talk">Discuss this process ${ARROW}</a>
          <button type="button" class="btn btn-line" id="xp-copy">Copy link to this view</button>
        </div>
        <p class="fine" id="xp-copied" role="status"></p>`;
    };

    xp.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.f) set({ f: b.dataset.f, p: "", q: "" });
      else if (b.dataset.p) { const cur = resolve(); writeHash({ f: byId.get(b.dataset.p).f.functionId, p: b.dataset.p, i: cur.i, c: cur.c, q: cur.q }, true); render("proc"); }
      else if (b.dataset.i) set({ i: b.dataset.i }, false);
      else if (b.dataset.c) set({ c: b.dataset.c }, false);
      else if ("clear" in b.dataset) { set({ q: "" }); $("#xp-q").focus(); }
      else if (b.id === "xp-copy") navigator.clipboard?.writeText(location.href).then(() => ($("#xp-copied").textContent = "Link copied."), () => ($("#xp-copied").textContent = "Copy the address from your browser bar."));
    });
    xp.addEventListener("change", (e) => { if (e.target.id === "xp-fn-select") set({ f: e.target.value, p: "", q: "" }); });
    let qt; xp.addEventListener("input", (e) => { if (e.target.id === "xp-q") { clearTimeout(qt); qt = setTimeout(() => set({ q: e.target.value }, false), 180); } });
    addEventListener("popstate", () => T && render(false));
    boot();
  }

  /* ------------------------------------------------------------------ Pain-point library */
  const pp = $("#pp");
  if (pp) {
    const shell = pp.innerHTML; let D;
    const PAGE = 24;
    const boot = async () => {
      pp.innerHTML = shell; pp.setAttribute("aria-busy", "true");
      try { D = await load("pain-points"); } catch { return failed(pp, boot); }
      pp.removeAttribute("aria-busy");
      const fns = [...new Map(D.painPoints.map((x) => [x.functionId, x.functionName])).entries()];
      const cats = [...new Map(D.painPoints.map((x) => [x.category, x.categoryLabel])).entries()].sort((a, b) => a[1].localeCompare(b[1]));
      $("#pp-f").innerHTML = `<option value="">All functions</option>` + fns.map(([id, n]) => `<option value="${id}">${esc(n)}</option>`).join("");
      $("#pp-k").innerHTML = `<option value="">All categories</option>` + cats.map(([id, n]) => `<option value="${id}">${esc(n)}</option>`).join("");
      render();
    };
    const st = () => { const h = readHash(); return { f: h.f || "", k: h.k || "", s: h.s || "", q: h.q || "", p: h.p || "", n: Math.max(PAGE, +h.n || PAGE) }; };
    const set = (patch, push = false) => { writeHash({ ...st(), n: "", ...patch }, push); render(); };
    const render = () => {
      const s = st(), sev = s.s ? s.s.split(",") : [];
      $("#pp-f").value = s.f; $("#pp-k").value = s.k; if (document.activeElement !== $("#pp-q")) $("#pp-q").value = s.q;
      $("#pp-sev").innerHTML = SEV.map((v) => `<button type="button" class="chip sev-chip psev-${v.toLowerCase()}" data-sev="${v}" aria-pressed="${sev.includes(v)}">${v}</button>`).join("");
      const terms = s.q.toLowerCase().split(/\s+/).filter(Boolean);
      const rows = D.painPoints.filter((x) => (!s.f || x.functionId === s.f) && (!s.k || x.category === s.k) && (!sev.length || sev.includes(x.severity)) && (!s.p || x.processId === s.p) &&
        terms.every((t) => (x.title + " " + x.impact + " " + x.processName + " " + x.taskName + " " + x.stepText).toLowerCase().includes(t)))
        .sort((a, b) => SEV.indexOf(a.severity) - SEV.indexOf(b.severity));
      const procLabel = s.p ? (D.painPoints.find((x) => x.processId === s.p) || {}).processName : "";
      $("#pp-scope").innerHTML = s.p ? `Showing process <b>${esc(s.p)} ${esc(procLabel || "")}</b>. <button type="button" class="linkish" data-unscope>Show all processes</button>` : "";
      $("#pp-count").textContent = `${rows.length} of ${D.painPoints.length} pain points`;
      const shown = rows.slice(0, s.n);
      $("#pp-list").innerHTML = shown.length ? shown.map((x) => `
        <li class="pp-card">
          <div class="pp-top"><span class="psev psev-${x.severity.toLowerCase()}">${esc(x.severity)}</span><span class="cat">${esc(x.categoryLabel)}</span></div>
          <h3>${esc(x.title)}</h3>
          <p>${esc(x.impact)}</p>
          <p class="path"><span>${esc(x.functionName)}</span> › <span>${esc(x.processId)} ${esc(x.processName)}</span> › <span>${esc(x.taskName)}</span> · step ${x.stepIndex + 1}: ${esc(x.stepText)}</p>
          <a class="text-link" href="explore.html#f=${encodeURIComponent(x.functionId)}&p=${encodeURIComponent(x.processId)}">Open this process in the explorer ${ARROW}</a>
        </li>`).join("") : `<li class="pp-empty"><h3>No pain points match these filters.</h3><p><button type="button" class="btn btn-line" data-reset>Clear all filters</button></p></li>`;
      $("#pp-more").hidden = rows.length <= s.n;
      $("#pp-more").textContent = `Show ${Math.min(PAGE, rows.length - s.n)} more`;
    };
    pp.addEventListener("change", (e) => { if (e.target.id === "pp-f") set({ f: e.target.value }); if (e.target.id === "pp-k") set({ k: e.target.value }); });
    let qt; pp.addEventListener("input", (e) => { if (e.target.id === "pp-q") { clearTimeout(qt); qt = setTimeout(() => set({ q: e.target.value }), 180); } });
    pp.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.sev) { const cur = st().s ? st().s.split(",") : []; const nx = cur.includes(b.dataset.sev) ? cur.filter((v) => v !== b.dataset.sev) : [...cur, b.dataset.sev]; set({ s: nx.join(",") }); }
      else if ("reset" in b.dataset) { writeHash({}, false); render(); $("#pp-q").focus(); }
      else if ("unscope" in b.dataset) set({ p: "" });
      else if (b.id === "pp-more") { const s = st(), first = s.n; writeHash({ ...s, n: s.n + PAGE }, false); render(); $$("#pp-list > li")[first]?.querySelector("h3")?.setAttribute("tabindex", "-1"); $$("#pp-list > li")[first]?.querySelector("h3")?.focus(); }
    });
    addEventListener("popstate", () => D && render());
    boot();
  }
})();
