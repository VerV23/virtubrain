#!/usr/bin/env bash
# Post-deploy check: every page loads and every asset it references returns 200 with the right type.
# Usage: ./smoke.sh https://ai-demolab.netlify.app
B="${1:?site URL}"; fail=0
for p in / platform.html explore.html pain-points.html approach.html practice.html contact.html; do
  html=$(curl -s "$B/$p"); code=$(curl -s -o /dev/null -w "%{http_code}" "$B/$p")
  [ "$code" = 200 ] || { echo "FAIL page $p -> $code"; fail=1; }
  for a in $(printf "%s" "$html" | grep -oE 'assets/[A-Za-z0-9._/-]+\.(css|js|webp)' | sort -u); do
    r=$(curl -s -o /dev/null -w "%{http_code} %{content_type}" "$B/$a")
    case "$r" in 200\ text/css*|200\ application/javascript*|200\ image/webp*) ;; *) echo "FAIL $p -> $a : $r"; fail=1;; esac
  done
done
for d in data/master-taxonomy.json data/pain-points.json; do r=$(curl -s -o /dev/null -w "%{http_code} %{content_type}" "$B/$d"); case "$r" in 200\ application/json*) ;; *) echo "FAIL $d : $r"; fail=1;; esac; done
[ $fail = 0 ] && echo "OK: all pages, assets and demo data load" || exit 1
