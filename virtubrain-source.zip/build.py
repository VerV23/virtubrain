"""Build the VirtuBrain static site into ./site (Netlify-ready). Content facts come from the live
VirtuBrain platform (virtubrain.higgsfield.app, read 23 Sep 2026) via src/data.json."""
import json, pathlib, html
ROOT = pathlib.Path(__file__).parent
OUT = ROOT / "site"
DATA = json.loads((ROOT / "src/data.json").read_text())
PLATFORM = "https://virtubrain.higgsfield.app"  # data origin only; proxied same-origin by Netlify at /data/*
PRACTICE = "Verantis"            # practice name: change here and rebuild
PRACTICE_LINE = "Operating-model advisory"
EMAIL = "vervillarico23@gmail.com"
FNS = DATA["functions"]
TOTAL_P = sum(f[2] for f in FNS)
TOTAL_PAIN = sum(s[1] for s in DATA["severity"])
e = html.escape
import hashlib, shutil
def _hash(b): return hashlib.sha256(b).hexdigest()[:10]
# Every asset gets a content hash in its file name, so a browser can never reuse a stale copy
# (Netlify caches /assets/* for a week, including 404s).
shutil.rmtree(OUT / "assets", ignore_errors=True); (OUT / "assets" / "img").mkdir(parents=True)
A = {}
for f in sorted((ROOT / "src/img").glob("*.webp")):
    b = f.read_bytes(); n = f"{f.stem}.{_hash(b)}.webp"; (OUT / "assets/img" / n).write_bytes(b); A["img/" + f.name] = "assets/img/" + n
for f in ["site.css", "site.js", "boot.js", "demos.js"]:
    b = (ROOT / "src/assets" / f).read_bytes(); stem, ext = f.rsplit(".", 1); n = f"{stem}.{_hash(b)}.{ext}"; (OUT / "assets" / n).write_bytes(b); A[f] = "assets/" + n
IMG = lambda name: A["img/" + name + ".webp"]

ARROW = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10h11M11 5l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
EXT = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M8 4H4v12h12v-4M11 3h6v6M17 3l-8 8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
LOGO = '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M16 16 L25 9" stroke="#E3A33B" stroke-width="2.2" stroke-linecap="round"/><circle cx="16" cy="16" r="2.6" fill="currentColor"/><path d="M5 20h3M24 20h3M16 4v3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'

PAGES = [("index.html", "Home"), ("platform.html", "Platform"), ("explore.html", "Explorer"), ("pain-points.html", "Pain points"), ("approach.html", "Approach"), ("practice.html", "Practice")]

def page(fn, title, desc, body, dark_top=True):
    PRELOAD = f'<link rel="preload" as="image" href="{IMG("hero-strategy-room")}" imagesrcset="{IMG("hero-strategy-room-800")} 800w, {IMG("hero-strategy-room")} 1376w" imagesizes="100vw">' if fn == "index.html" else ""
    nav = "".join(f'<a href="{p}"{" aria-current=\"page\"" if p == fn else ""}>{n}</a>' for p, n in PAGES[1:])
    return (f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
<meta property="og:type" content="website"><meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(desc)}">
<meta name="theme-color" content="#0C1B2A">
<link rel="icon" href="data:image/svg+xml,{LOGO.replace('"', "'").replace('currentColor', '%230C1B2A').replace('#', '%23').replace("%23E3A33B", "%23E3A33B")}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Space+Grotesk:wght@400;500;600&display=swap">
<link rel="stylesheet" href="{A['site.css']}">{PRELOAD}
<script src="{A['boot.js']}"></script>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site-head{'' if dark_top else ' light'}">
  <div class="wrap">
    <a class="brand" href="index.html" aria-label="VirtuBrain home">{LOGO}<span><b>VirtuBrain</b><small>by {PRACTICE}</small></span></a>
    <button class="menu-btn" aria-expanded="false" aria-controls="nav">Menu</button>
    <nav id="nav" class="nav" aria-label="Main">{nav}<a class="btn btn-amber" href="contact.html"{" aria-current=\"page\"" if fn == "contact.html" else ""}>Talk to us</a></nav>
  </div>
</header>
<main id="main" tabindex="-1">
{body}
</main>
<footer class="site-foot">
  <div class="wrap">
    <div class="foot-grid">
      <div><a class="brand" href="index.html" style="color:var(--bone)">{LOGO}<span><b>VirtuBrain</b><small>by {PRACTICE}</small></span></a>
        <p style="margin-top:18px;max-width:30em">A calibration instrument for the enterprise operating model, built and maintained by {PRACTICE}, an operating-model advisory practice for finance, HR and shared services.</p></div>
      <div><h2>Explore</h2><ul><li><a href="explore.html">Framework explorer</a></li><li><a href="pain-points.html">Pain-point library</a></li><li><a href="platform.html">How the platform works</a></li><li><a href="approach.html">How engagements run</a></li></ul></div>
      <div><h2>Contact</h2><ul><li><a href="mailto:{EMAIL}">{EMAIL}</a></li><li>Philippines, working with clients across the Philippines, the United States and Singapore</li><li><a href="contact.html">Send a message</a></li></ul></div>
    </div>
    <div class="legal"><p style="margin:0;max-width:62em">VirtuBrain and its taxonomy provide general information on business-process design and operating-model benchmarking. Nothing here is legal, tax or regulatory advice. We use your contact details only to reply to what you send.</p><p style="margin:0">Photographs are AI-generated illustrations, not clients or staff. © 2026 Process Reinvention Hub</p></div>
  </div>
</footer>
<script type="application/json" id="vb-data">{json.dumps(DATA)}</script>
<script src="{A['site.js']}" defer></script>{'<script src="' + A['demos.js'] + '" defer></script>' if fn in ("explore.html", "pain-points.html") else ""}
</body>
</html>""").replace("Process Reinvention Hub", PRACTICE)

def img(name, alt, eager=False, pos="center"):
    return (f'<img src="{IMG(name)}" srcset="{IMG(name + "-800")} 800w, {IMG(name)} 1376w" sizes="100vw" '
            f'alt="{e(alt)}" width="1376" height="768" style="object-position:{pos}" ' + ('fetchpriority="high"' if eager else 'loading="lazy" decoding="async"') + '>')

def photo(name, alt, caption="", pos="center"):
    return f'<figure class="photo reveal">{img(name, alt, pos=pos)}{f"<figcaption>{e(caption)}</figcaption>" if caption else ""}</figure>'

def head(kicker, title, lede, image, alt, extra="", pos="center"):
    return f"""<section class="page-head dark has-media"><div class="ph-media">{img(image, alt, eager=True, pos=pos)}</div><div class="wrap">
  <p class="kicker">{kicker}</p>
  <h1 class="display">{title}</h1>
  <p class="lede">{lede}</p>{extra}
</div></section>"""

CTA_FORM = f"""
<section class="band dark cta" aria-labelledby="cta-h">
  <div class="wrap">
    <p class="kicker">Start with one process</p>
    <h2 id="cta-h" class="h2">Bring the process that keeps breaking. We'll show you the step where it breaks.</h2>
    <div class="cta-grid">
      <div>
        <p class="lede">In a first conversation we open your function in VirtuBrain, calibrate it to your industry and country, and walk through the pain points that apply, so you can see where the work stalls before deciding anything.</p>
        <p class="fine">Or email <a href="mailto:{EMAIL}">{EMAIL}</a> directly.</p>
      </div>
      <form class="form" id="talk" name="talk" method="POST" data-netlify="true" netlify-honeypot="company-website" novalidate>
        <input type="hidden" name="form-name" value="talk">
        <p class="hp"><label>Leave this empty <input name="company-website" tabindex="-1" autocomplete="off"></label></p>
        <div><label for="t-name">Your name</label><input id="t-name" name="name" autocomplete="name" required aria-describedby="e-name"><div class="err" id="e-name" aria-live="polite"></div></div>
        <div><label for="t-email">Work email</label><input id="t-email" name="email" type="email" autocomplete="email" required aria-describedby="e-email"><div class="err" id="e-email" aria-live="polite"></div></div>
        <div><label for="t-company">Company (optional)</label><input id="t-company" name="company" autocomplete="organization"></div>
        <div><label for="t-fn">Function to start with (optional)</label><select id="t-fn" name="function"><option value="">Not sure yet</option>{"".join(f"<option>{e(f[0])}</option>" for f in FNS)}</select></div>
        <div><label for="t-msg">What should we calibrate?</label><textarea id="t-msg" name="message" required aria-describedby="e-message"></textarea><div class="err" id="e-message" aria-live="polite"></div></div>
        <div class="row"><button class="btn btn-amber" type="submit">Send</button><span class="fine">Replies come from {EMAIL}.</span></div>
        <div id="talk-status" role="status" tabindex="-1"></div>
      </form>
    </div>
  </div>
</section>"""

# ---------------- HOME ----------------
fn_cells = "".join(f'<div class="fn-cell{" hot" if i == 5 else ""}">{e(f[0])}<em>{f[2]} processes</em></div>' for i, f in enumerate(FNS))
bars = "".join(f'<div class="bar{" top" if i == 0 else ""}"><span>{e(c)}</span><span class="num">{n}</span><div class="track"><div class="fill" data-w="{n / DATA["categories"][0][1] * 100:.1f}%"></div></div></div>' for i, (c, n) in enumerate(DATA["categories"]))
sev_col = {"High": "var(--amber)", "Medium": "var(--teal-2)", "Low": "#46627b"}
sev = "".join(f'<div style="border-color:{sev_col[s]}"><b class="num" data-count="{n}">{n}</b>{s} severity</div>' for s, n in DATA["severity"])

home = f"""
<section class="hero dark" aria-labelledby="hero-h">
  <div class="hero-media">{img("hero-strategy-room", "", eager=True, pos="72% center")}</div>
  <div class="wrap">
    <div>
      <p class="kicker">Operating-model calibration for finance, HR and shared services</p>
      <h1 id="hero-h" class="display">Find the step where your operating model breaks.</h1>
      <p class="lede">VirtuBrain maps the enterprise from its thirteen business functions down to individual steps, calibrated by industry and country, and shows where the work stalls. {PRACTICE} uses it to redesign operations with clients across the Philippines, the United States and Singapore.</p>
      <div class="row"><a class="btn btn-amber" href="explore.html">Open the explorer {ARROW}</a><a class="btn btn-line" href="#story">See how it calibrates {ARROW}</a></div>
      <div class="hero-facts" aria-label="Platform coverage">
        <div><b>13</b>business functions</div><div><b>{TOTAL_P}</b>Level 3 processes</div><div><b>6</b>industries</div><div><b>3</b>countries: PH, US, SG</div>
      </div>
    </div>
  </div>
</section>

<section class="band dark instrument" aria-labelledby="dial-h">
  <div class="wrap split" style="align-items:center">
    <div class="dial-wrap">
      <svg class="dial" id="dial" viewBox="0 0 520 520" role="img" aria-labelledby="dial-title">
        <title id="dial-title">A calibration dial with one mark for each of the thirteen business functions, sized by how many processes each contains.</title>
        <circle class="ring" cx="260" cy="260" r="236"/><circle class="ring" cx="260" cy="260" r="150" stroke-dasharray="2 6"/>
        <g id="dial-ticks"></g>
        <g class="needle"><line x1="260" y1="260" x2="260" y2="72" stroke="#E3A33B" stroke-width="3" stroke-linecap="round"/><circle cx="260" cy="260" r="9" fill="#E3A33B"/><circle cx="260" cy="260" r="3.5" fill="#0C1B2A"/></g>
      </svg>
      <div class="dial-read" id="dial-read" aria-live="off"><b></b><span></span></div>
      <p style="text-align:center;margin-top:8px"><button id="dial-pause" class="btn btn-line" style="min-height:40px;padding:8px 16px;font-size:14px;color:#b7c4cf" aria-pressed="false">Pause the dial</button></p>
    </div>
    <div>
      <p class="kicker">One instrument</p>
      <h2 id="dial-h" class="h2">Thirteen functions, read on a single dial.</h2>
      <p class="lede" style="margin-top:24px">Every mark is a business function, sized by how many Level 3 processes it holds. The same six-level structure runs through each one, so finance, HR and supply chain can be compared step for step.</p>
    </div>
  </div>
</section>

<section id="story" class="story" aria-labelledby="story-h">
  <h2 id="story-h" class="sr-only">From function to step: one process, four levels</h2>
  <div class="story-stage">
    <div class="story-copy">
      <div class="story-step on"><p class="lvl">Level 1 <i><b></b></i></p><h3>Start with the whole enterprise.</h3><p class="lede">Thirteen business functions, each broken into process groups and {TOTAL_P} Level 3 processes. Pick the one that hurts.</p></div>
      <div class="story-step"><p class="lvl">Level 3 <i><b></b></i></p><h3>Open one real process.</h3><p class="lede">Manage Warehouse Operations: what triggers it, what it must produce, and who owns the outcome.</p></div>
      <div class="story-step"><p class="lvl">Levels 4 and 5 <i><b></b></i></p><h3>See how the work is really divided.</h3><p class="lede">Three process groups and six activities, from receiving stock to planning labour against forecast volume.</p></div>
      <div class="story-step"><p class="lvl">Level 6 <i><b></b></i></p><h3>Down to the step where it stalls.</h3><p class="lede">Every activity resolves into tasks, decisions and handoffs. This is where pain points attach, and where redesign starts.</p></div>
    </div>
    <div class="story-canvas">
      <div class="scene on" aria-label="Level 1: thirteen business functions">
        <p class="scene-title"><span>13 functions</span><span>{TOTAL_P} Level 3 processes</span></p>
        <div class="fn-grid">{fn_cells}</div>
      </div>
      <div class="scene" aria-label="Level 3: Manage Warehouse Operations">
        <p class="scene-title"><span>Supply Chain, Operations and Logistics</span><span>Process 4.4.1</span></p>
        <div class="proc"><span class="fine">Level 3 process</span><h4>Manage Warehouse Operations</h4>
          <dl><dt>Starts when</dt><dd>A new warehouse operations cycle begins, or an exception surfaces that needs attention.</dd>
          <dt>Produces</dt><dd>A current, actively managed warehouse position, with exceptions resolved and status reported to stakeholders.</dd>
          <dt>Breaks into</dt><dd>3 process groups, 6 activities, and step-level detail for each.</dd></dl></div>
      </div>
      <div class="scene" aria-label="Levels 4 and 5: process groups and activities">
        <p class="scene-title"><span>Manage Warehouse Operations</span><span>Levels 4 and 5</span></p>
        <div class="grp-list">
          <div class="grp"><div><b>4.4.1.1 Inbound receiving and putaway</b><div class="fine">Receive and verify inbound shipments. Put away stock to storage locations.</div></div></div>
          <div class="grp hot"><div><b>4.4.1.2 Fulfil outbound customer and store orders</b><div class="fine">Release and prioritise orders for picking. Pick, pack and stage outbound shipments.</div></div></div>
          <div class="grp"><div><b>4.4.1.3 Warehouse labour and slotting</b><div class="fine">Plan labour to forecast volume. Optimise storage slotting and facility layout.</div></div></div>
        </div>
      </div>
      <div class="scene" aria-label="Level 6: pick, pack and stage outbound shipments">
        <p class="scene-title"><span>4.4.1.2.2 Pick, pack and stage outbound shipments</span><span>Level 6</span></p>
        <div class="flow">
          <div class="ev"><small style="color:#93a3b1">Start</small>Orders released for picking</div>
          <div class="task"><small>Task</small>Release a wave or batch of orders to pick devices (RF scanner or voice-pick)</div>
          <div class="task"><small>Task</small>Pick items along the optimised pick path: each, case or pallet</div>
          <div class="gw"><small>Check</small>Consolidate picks at the packing station and verify against the order</div>
          <div class="task"><small>Task</small>Pack into cartons with dunnage and print the shipping label</div>
          <div class="task"><small>Task</small>Stage cartons and pallets in the outbound lane by carrier and route</div>
          <div class="task"><small>Task</small>Load and manifest onto the outbound trailer and confirm the ASN</div>
        </div>
      </div>
      <div class="story-progress" aria-hidden="true"><i class="on"></i><i></i><i></i><i></i></div>
    </div>
  </div>
</section>

{photo("warehouse", "An operations lead checking a tablet in a warehouse aisle.", caption="The flagship process on this page, Manage Warehouse Operations, is modeled down to the individual step.", pos="center 45%")}

<section class="band dark" aria-labelledby="pain-h">
  <div class="wrap">
    <div class="split reveal">
      <div><p class="kicker">Where the model breaks down</p><h2 id="pain-h" class="h2">Pain points, pinned to the exact step.</h2></div>
      <p class="lede">Each record names a category and severity, states the business impact, and links to the Level 6 step where it happens. Handoffs and system friction dominate, which is exactly where redesign pays back first.</p>
    </div>
    <div class="readout" data-observe>
      <div>
        <div class="big-count num" data-count="{TOTAL_PAIN}">{TOTAL_PAIN}</div>
        <p class="fine" style="margin-top:12px">pain-point records across all {TOTAL_P} processes</p>
        <div class="sev">{sev}</div>
        <blockquote style="margin:40px 0 0;padding:20px 22px;border-left:3px solid var(--amber);background:rgba(255,255,255,.03)">
          <p class="fine" style="margin-bottom:6px">Example record: high severity, control and compliance gap</p>
          <p style="margin:0">Approval evidence is inconsistent at final supplier negotiation and selection. An estimated 30% of cases proceed without a documented control, creating audit exposure.</p>
        </blockquote>
      </div>
      <div><p class="fine" style="margin-bottom:18px">Records by category</p><div class="bars">{bars}</div></div>
    </div>
    <p class="caveat">The pain-point library is illustrative and representative: modeled on process-mining conventions to show what a diagnosis looks like, not an audited finding about any organisation. In an engagement, the same structure is filled with your own evidence.</p>
    <p style="margin-top:28px"><a class="btn btn-line" href="pain-points.html">Browse all {TOTAL_PAIN} records {ARROW}</a></p>
  </div>
</section>

<section class="band" aria-labelledby="ex-h">
  <div class="wrap">
    <div class="split reveal">
      <div><p class="kicker">The framework, live</p><h2 id="ex-h" class="h2">Every function, measured the same way.</h2></div>
      <p class="lede">Choose a function to see its coverage. In the full platform you can open any process, switch between six industries and three countries, and watch the requirements, systems and KPIs change.</p>
    </div>
    <div class="explorer reveal" id="explorer">
      <nav role="tablist" aria-label="Business functions" aria-orientation="vertical"></nav>
      <div class="pane" id="fn-pane" role="tabpanel">
        <div><p class="fine">Business function</p><h3></h3>
          <div class="stat-pair"><div><b class="num" id="ex-groups"></b><span>process groups</span></div><div><b class="num" id="ex-procs"></b><span>Level 3 processes</span></div></div>
          <div class="meter" aria-hidden="true"></div></div>
        <div class="row"><a class="btn btn-amber" id="ex-open" href="explore.html">Open this function in the explorer {ARROW}</a><span class="fine">Industries: retail, technology, insurance, banking, hotel and hospitality, manufacturing.</span></div>
      </div>
    </div>
  </div>
</section>

{photo("workshop", "Consultants mapping a process on a wall of cards during a discovery workshop.", pos="center 35%")}

<section class="band" aria-labelledby="eng-h" style="padding-top:clamp(64px,8vw,120px)">
  <div class="wrap">
    <div class="split reveal">
      <div><p class="kicker">How we work with it</p><h2 id="eng-h" class="h2">From map to redesign in four moves.</h2></div>
      <p class="lede">VirtuBrain is the instrument. The engagement is where it gets filled with your evidence and turned into decisions.</p>
    </div>
    <div class="eng reveal">
      <article><p class="step">1</p><h3>Calibrate</h3><p>Lay your operating model against the taxonomy for your industry and country, and agree on scope.</p></article>
      <article><p class="step">2</p><h3>Diagnose</h3><p>Find the steps where work stalls: handoffs, rework, control gaps, manual effort. Each finding is tied to its step.</p></article>
      <article><p class="step">3</p><h3>Redesign</h3><p>Decide which steps agents run alone, which they draft for approval, and which stay with people. Design the controls and evidence.</p></article>
      <article><p class="step">4</p><h3>Run</h3><p>Stand up the new model in finance, HR or shared services, and measure it against the KPIs agreed at the start.</p></article>
    </div>
    <p style="margin-top:40px"><a class="btn btn-line" href="approach.html">See how engagements run {ARROW}</a></p>
  </div>
</section>

<section class="band dark" aria-labelledby="prh-h">
  <div class="wrap split reveal">
    <div><p class="kicker">Built by practitioners</p><h2 id="prh-h" class="h2">Made by a working transformation practice, not a taxonomy vendor.</h2></div>
    <div><p class="lede">{PRACTICE} is an operating-model advisory practice for AI-enabled process transformation and for shared-services and global business services design. VirtuBrain is its own instrument, built so anyone evaluating an operating model can use the same method.</p><p><a class="btn btn-line" href="practice.html">About the practice {ARROW}</a></p></div>
  </div>
</section>
{CTA_FORM}
"""

# ---------------- PLATFORM ----------------
platform = f"""
{head("The platform", "A precision taxonomy of how the enterprise works.", "VirtuBrain breaks every business function into process groups, processes and steps, then calibrates each one by industry and country. It is free to explore.", "warehouse", "An operations lead reviewing a tablet in a long warehouse aisle.", extra=f'''
  <div class="row" style="margin-top:36px"><a class="btn btn-amber" href="explore.html">Open the explorer {ARROW}</a><a class="btn btn-line" href="pain-points.html">Browse pain points {ARROW}</a></div>
  <div class="dl-grid"><div><b style="color:var(--bone)">13</b><span>business functions</span></div><div><b style="color:var(--bone)">{TOTAL_P}</b><span>Level 3 processes</span></div><div><b style="color:var(--bone)">6</b><span>industries</span></div><div><b style="color:var(--bone)">{TOTAL_PAIN}</b><span>illustrative pain-point records</span></div></div>''', pos="50% 40%")}
<section class="band"><div class="wrap prose">
  <h2 style="margin-top:0">Six levels, one vocabulary</h2>
  <p>Levels 1 to 3 cover functions, process groups and processes. Levels 4 and 5 divide each process into groups of activities. Level 6 is the step: a task, a decision point or a handoff, drawn as a flow from start event to end event.</p>
  <p>Every one of the {TOTAL_P} Level 3 processes renders a full flow. Flagship processes, such as Manage Warehouse Operations, carry curated step detail throughout. The others carry flows modeled systematically from their own Level 3 to 5 structure, and are labelled that way inside the diagram.</p>
  <h2>Calibrated by industry and country</h2>
  <p>Switch the lens and the same process changes. For Assess the External Environment, the retail lens focuses on consumer spending shifts, competitors' store and e-commerce footprint, and seasonal demand. The Philippines lens adds monetary-policy signals from the central bank, changes to investment-incentive regimes, and national consumer-confidence data. Each process also lists typical systems and representative KPIs.</p>
  <p>Industries: retail, technology, insurance, banking, hotel and hospitality, and manufacturing. Countries: the Philippines, the United States and Singapore.</p>
  <h2>Pain points linked to steps</h2>
  <p>The pain-point library holds {TOTAL_PAIN} records across eight categories, from handoff friction to control gaps. Each has a severity, a business-impact statement and a link to its Level 6 step. The library is illustrative: modeled on process-mining conventions, not audited findings about any organisation.</p>
  <h2>In the tradition of process classification frameworks</h2>
  <p>The method follows process-classification-framework practice, in the tradition of frameworks such as APQC's Process Classification Framework, applied to real operating models.</p>
</div></section>
{CTA_FORM}
"""

# ---------------- APPROACH ----------------
approach = f"""
{head("Approach", "Diagnose at the step. Redesign with evidence.", "Engagements use VirtuBrain as the shared map, so everyone argues about the same step instead of the same slide. Scope and length are set with each client.", "workshop", "Three consultants mapping a process flow on a wall of cards.", pos="60% center")}
<section class="band"><div class="wrap">
  <div class="eng" style="margin-top:0">
    <article><p class="step">1</p><h3>Calibrate</h3><p>Agree which functions and processes are in scope, then lay your current model against the taxonomy for your industry and country.</p><ul><li>Scope by function and process</li><li>Current-state map at Levels 3 to 5</li><li>KPI baseline you already track</li></ul></article>
    <article><p class="step">2</p><h3>Diagnose</h3><p>Walk the flows with the people who run them. Record where work waits, loops, or escapes control, and size the impact.</p><ul><li>Pain points tied to Level 6 steps</li><li>Severity and business impact</li><li>Evidence from your own systems and interviews</li></ul></article>
    <article><p class="step">3</p><h3>Redesign</h3><p>For each step, decide whether an agent runs it alone, drafts it for a person to approve, or leaves it with people. Design the controls that prove it worked.</p><ul><li>Target flows at Level 6</li><li>Automation and agent decisions with rationale</li><li>Control and evidence design</li></ul></article>
    <article><p class="step">4</p><h3>Run</h3><p>Stand up the new model in finance, HR or shared services, and track it against the baseline.</p><ul><li>Transition plan by wave</li><li>Operating rhythm and ownership</li><li>KPI tracking against baseline</li></ul></article>
  </div>
</div></section>
{photo("finance-review", "Two finance professionals reviewing a month-end reconciliation together.", pos="center 30%")}
<section class="band dark"><div class="wrap">
  <div class="split"><div><p class="kicker">Principles</p><h2 class="h2">How we make the calls.</h2></div><p class="lede">Three rules shape every redesign.</p></div>
  <div class="principles">
    <div><h3>Name the step, not the theme.</h3><p>A finding that can't point to a step can't be fixed or measured. Every recommendation traces to one.</p></div>
    <div><h3>Automate what can be checked.</h3><p>Agents take the steps whose output can be verified against a system of record. Judgment stays with people until it can be checked.</p></div>
    <div><h3>Evidence before scale.</h3><p>Each change ships with the control that proves it works, so audit and finance leaders can sign off without trusting a demo.</p></div>
  </div>
</div></section>
{CTA_FORM}
"""

# ---------------- PRACTICE ----------------
practice = f"""
{head(PRACTICE, "The practice behind the instrument.", f"{PRACTICE} is an operating-model advisory practice for finance, HR and shared-services leaders. Based in Manila, working with clients in the Philippines, the United States and Singapore.", "gbs-floor", "A global business services floor in Manila at night.")}
<section class="band"><div class="wrap prose">
  <h2 style="margin-top:0">What we do</h2>
  <p>We redesign finance, HR and shared-services operations for an agentic operating model: which work agents do alone, which they prepare for people to approve, and which stays with people. Every recommendation is tied to a step in VirtuBrain, so it can be scoped, built and measured.</p>
  <h2>Who leads it</h2>
  <p>{PRACTICE} is founded and led by Ver Villarico, a Consulting Director at Accenture. His work spans process transformation at process-classification-framework level, including record-to-report, procure-to-pay and order-to-cash; global business services and shared-services delivery; and enterprise ERP ecosystems. The practice carries its own methods for agentic AI governance, audit-grade verifiability and continuous close.</p>
  <h2>Why the name</h2>
  <p>{PRACTICE} comes from the Latin <i>verus</i>, true. It is the standard every redesign is held to: when an agent takes over a step, its result can be checked against a system of record, and a person can prove it worked.</p>
  <h2>Why we built VirtuBrain</h2>
  <p>Most operating-model work lives in slide decks that no one can navigate after the engagement ends. VirtuBrain makes the method usable by anyone evaluating an operating model, not only clients in an engagement. <a href="explore.html">Open the explorer</a> or <a href="pain-points.html">browse the pain-point library</a>.</p>
</div></section>
{CTA_FORM}
"""

contact = f"""
{head("Contact", "Talk to the practice.", "Tell us which process keeps breaking. We'll reply from vervillarico23@gmail.com.", "finance-review", "Two finance professionals reviewing a reconciliation together.", pos="center 30%")}
{CTA_FORM}
"""

explore = f"""
<section class="page-head dark demo-head"><div class="wrap">
  <p class="kicker">VirtuBrain framework explorer</p>
  <h1 class="display">Open any process. Calibrate it to your world.</h1>
  <p class="lede">Choose a function, open one of its {TOTAL_P} processes, and switch the industry and country lens. Every view has its own link, so you can share exactly what you're looking at.</p>
</div></section>
<section class="demo"><div class="wrap">
  <div class="xp" id="xp" aria-busy="true">
    <div class="lens-bar">
      <div class="lens" role="group" aria-labelledby="lens-i-l"><span id="lens-i-l">Industry</span><div id="lens-i"></div></div>
      <div class="lens" role="group" aria-labelledby="lens-c-l"><span id="lens-c-l">Country</span><div id="lens-c"></div></div>
    </div>
    <div class="xp-grid">
      <nav class="xp-fns" id="xp-fns" aria-label="Business functions"><div class="skel"></div><div class="skel"></div><div class="skel"></div></nav>
      <div class="xp-list">
        <label class="sr-only" for="xp-fn-select">Business function</label><select id="xp-fn-select" class="xp-fn-select"></select>
        <label class="search"><span class="sr-only">Search all processes</span><input id="xp-q" type="search" placeholder="Search all 142 processes" autocomplete="off"></label>
        <div id="xp-procs" aria-live="polite"><div class="skel"></div><div class="skel"></div></div>
      </div>
      <article class="xp-detail" id="xp-detail" aria-live="off"><p class="fine">Loading the framework…</p></article>
    </div>
  </div>
  <p class="fine demo-note">Taxonomy in the tradition of process classification frameworks. Industry and country notes are general guidance, not legal, tax or regulatory advice.</p>
</div></section>
{CTA_FORM}
"""

painpage = f"""
<section class="page-head dark demo-head"><div class="wrap">
  <p class="kicker">VirtuBrain pain-point library</p>
  <h1 class="display">Where work stalls, step by step.</h1>
  <p class="lede">{TOTAL_PAIN} records across all {TOTAL_P} processes, each tied to the exact step where it happens. Filter by function, severity or category, then open the process behind any record.</p>
</div></section>
<section class="demo"><div class="wrap">
  <div id="pp" aria-busy="true">
    <div class="pp-filters">
      <div><label for="pp-f">Function</label><select id="pp-f"><option>Loading…</option></select></div>
      <div><label for="pp-k">Category</label><select id="pp-k"><option>Loading…</option></select></div>
      <div role="group" aria-labelledby="pp-sev-l"><span class="lbl" id="pp-sev-l">Severity</span><div id="pp-sev"></div></div>
      <div class="grow"><label for="pp-q">Search</label><input id="pp-q" type="search" placeholder="Try “handoff”, “approval” or “invoice”" autocomplete="off"></div>
    </div>
    <p id="pp-scope" class="pp-scope"></p>
    <p id="pp-count" class="xp-count" role="status" aria-live="polite"></p>
    <ul id="pp-list" class="pp-list"><li class="skel tall"></li><li class="skel tall"></li></ul>
    <p style="text-align:center"><button type="button" class="btn btn-line" id="pp-more" hidden>Show more</button></p>
  </div>
  <p class="caveat-light">The library is illustrative and representative: synthesized against the real process taxonomy in the style of process-mining risk registers, not audited findings about any organisation. In an engagement, the same structure is filled with your own evidence.</p>
</div></section>
{CTA_FORM}
"""

notfound = f"""<section class="page-head dark" style="min-height:70vh"><div class="wrap"><p class="kicker">Page not found</p><h1 class="display">That page isn't on this site.</h1><p class="lede">The address may be mistyped or the page moved. Start from the home page or open the platform.</p><div class="row" style="margin-top:32px"><a class="btn btn-amber" href="index.html">Go to the home page</a><a class="btn btn-line" href="explore.html">Open the explorer</a></div></div></section>"""

pages = {
  "index.html": ("VirtuBrain: find the step where your operating model breaks", f"VirtuBrain maps 13 business functions and {TOTAL_P} processes down to individual steps, calibrated by industry and country. Built by Process Reinvention Hub.", home),
  "platform.html": ("The VirtuBrain platform", "How VirtuBrain's six-level process taxonomy, industry and country calibration, and pain-point library work.", platform),
  "approach.html": ("Approach: VirtuBrain by Process Reinvention Hub", "How engagements calibrate, diagnose, redesign and run operating models using VirtuBrain.", approach),
  "practice.html": (f"{PRACTICE}: the practice behind VirtuBrain", "An operating-model advisory practice for AI-enabled process transformation and shared-services design.", practice),
  "explore.html": ("Framework explorer: VirtuBrain", f"Open any of {TOTAL_P} processes and calibrate it by industry and country.", explore),
  "pain-points.html": ("Pain-point library: VirtuBrain", f"{TOTAL_PAIN} illustrative pain points tied to the exact process step.", painpage),
  "contact.html": ("Contact: VirtuBrain by Process Reinvention Hub", "Talk to Process Reinvention Hub about calibrating your operating model.", contact),
  "404.html": ("Page not found: VirtuBrain", "Page not found.", notfound),
}
for fn, (t, d, b) in pages.items():
    (OUT / fn).write_text(page(fn, t, d, b))
(OUT / "netlify.toml").write_text("""[build]
  publish = "."

# The demos load their data same-origin; Netlify fetches it from the VirtuBrain data store.
[[redirects]]
  from = "/data/*"
  to = "https://virtubrain.higgsfield.app/data/:splat"
  status = 200
  force = true
[[headers]]
  for = "/*"
  [headers.values]
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
    X-Frame-Options = "DENY"
    Permissions-Policy = "camera=(), microphone=(), geolocation=()"
    Content-Security-Policy = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'"
[[headers]]
  for = "/assets/*"
  [headers.values]
    # Safe to cache for a year: every file name carries a content hash, so changes get new URLs.
    Cache-Control = "public, max-age=31536000, immutable"
[[headers]]
  for = "/data/*"
  [headers.values]
    Cache-Control = "public, max-age=300"
""")
print("built", list(pages))
